package estoque;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.text.PlainDocument;

public class NotaFiscalDAO extends PlainDocument {
    private Connection con;
    
    public NotaFiscalDAO() throws Exception {
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teste","root", "");
    }
    
    public List<NotaFiscal> obterTodasNotas() throws Exception {
        List<NotaFiscal> list = new ArrayList<>();
        PreparedStatement pstmt = null;
        ResultSet rset = null;
        
        pstmt = con.prepareStatement("SELECT * FROM teste.estoque");
        rset = pstmt.executeQuery();
        
        while (rset.next()) {
            int codigo = rset.getInt("codigo");
            String marca = rset.getString("marca");
            String modelo = rset.getString("modelo");
            int ano = rset.getInt("ano");
            String descricao = rset.getString("descricao");
            double valor = rset.getDouble("valor");

            NotaFiscal notas = new NotaFiscal (codigo, marca, modelo, 
                    ano, descricao, valor);
            list.add(notas);
        }
        pstmt.close();
        rset.close();
        return list;
    }
    
    public void insereNotas(NotaFiscal notas) throws Exception {
       PreparedStatement pstmt = null;
       
       pstmt = con.prepareStatement("INSERT INTO teste.estoque(codigo, marca, modelo, ano, descricao, valor) VALUES (?, ?, ?, ?, ?, ?)");
       pstmt.setInt(1, notas.getCodigo());
       pstmt.setString(2, notas.getMarca());
       pstmt.setString(3, notas.getModelo());
       pstmt.setInt(4, notas.getAno());
       pstmt.setString(5, notas.getDescricao());
       pstmt.setDouble(6, notas.getValor());
       pstmt.executeUpdate();
       pstmt.close();
    }
    
    public void atualizaNotas(NotaFiscal notas) throws Exception {
       PreparedStatement pstmt = null;
       
       pstmt = con.prepareStatement("UPDATE teste.estoque SET marca=?, modelo=?, ano=?, descricao=?, valor=? WHERE codigo=?");
       pstmt.setInt(1, notas.getCodigo());
       pstmt.setString(2, notas.getMarca());
       pstmt.setString(3, notas.getModelo());
       pstmt.setInt(4, notas.getAno());
       pstmt.setString(5, notas.getDescricao());
       pstmt.setDouble(6, notas.getValor());
       pstmt.executeUpdate();
       pstmt.close();
    }
    
    public void apagaPessoa(int codigo) throws Exception {
       PreparedStatement pstmt = null;
       
       pstmt = con.prepareStatement("DELETE FROM teste.estoque WHERE codigo=?");
       pstmt.setInt(1, codigo);
       pstmt.executeUpdate();
       pstmt.close();
    }
}